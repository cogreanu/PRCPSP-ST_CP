#!/bin/bash
# make sure we're in the directory of this file
cd -P -- "/scratch/cogreanu/default_runs" || exit

JOB_IDS=""
for CHUNK_DIR in runs_*/
do
  printf "Running chunk %s\n" "$CHUNK_DIR"

  # run the chunk
  JOB_IDS+="$("$CHUNK_DIR/run_chunk.sh"):"
done

sbatch --depend=afterany:${JOB_IDS::-1} post_process.job
