#!/bin/sh
# Copy directory structure of experiment back
rsync --archive --verbose --compress cogreanu@login.delftblue.tudelft.nl:/scratch/cogreanu/default_runs "/scratch/cogreanu/default_runs"
