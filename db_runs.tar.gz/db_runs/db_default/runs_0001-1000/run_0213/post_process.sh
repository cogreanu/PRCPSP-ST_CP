#!/bin/sh
# make sure we're in the directory of this file
cd -P -- "/scratch/cogreanu/default_runs/runs_0001-1000/run_0213" || exit
# Run the post-process command

