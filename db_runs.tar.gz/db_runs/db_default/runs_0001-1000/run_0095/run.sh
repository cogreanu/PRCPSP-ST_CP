#!/bin/sh
# make sure we're in the directory of this file
cd -P -- "/scratch/cogreanu/default_runs/runs_0001-1000/run_0095" || exit
# remove possible previous failed report
if [ -f driver.err ]; then
  rm driver.err
fi
if [ -f run.err ]; then
  rm run.err
fi
printf "name = \"_J120_19_4\"\nprogram = \"default\"\nfile = \"["../../../instances/J120_19_4.dzn"]\"\n" > driver.log
# Get gnu-time from environment, don't call shell built-in. Use it to record time information to driver.log about the run, while writing the exit code to driver.err iff the run fails.
env time --append --output=driver.log --format="wall_clock_time = %e\nsystem_time = %S\nuser_time = %U" \
   sh -c '( prcpsp-st "-s" "default" "-t" "600000" "1" "../../../instances/J120_19_4.dzn" > run.log 2> run.err ) || printf "exit_code = $?\n" > driver.err'
